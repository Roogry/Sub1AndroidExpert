package com.roogry.sub1androidexpert.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.roogry.sub1androidexpert.R;
import com.roogry.sub1androidexpert.model.MovieItem;

import java.util.ArrayList;

public class MovieAdapter extends BaseAdapter {
    private Context context;
    private ArrayList<MovieItem> movieItems;

    public MovieAdapter(Context context, ArrayList<MovieItem> movieItems) {
        this.context = context;
        this.movieItems = movieItems;
    }

    @Override
    public int getCount() {
        return movieItems.size();
    }

    @Override
    public Object getItem(int position) {
        return movieItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.movie_item, parent, false);
        }

        ViewHolder viewHolder = new ViewHolder(view);
        MovieItem movie = (MovieItem) getItem(position);
        viewHolder.bind(movie);
        return view;
    }

    private class ViewHolder {
        ImageView mvMovie;
        TextView txtTitle, txtGenre, txtDuration, txtOverview;


        ViewHolder(View view) {
            mvMovie = view.findViewById(R.id.mvMovie);
            txtTitle = view.findViewById(R.id.txtTitle);
            txtGenre = view.findViewById(R.id.txtGenre);
            txtDuration = view.findViewById(R.id.txtDuration);
            txtOverview = view.findViewById(R.id.txtOverview);
        }

        void bind(MovieItem movie) {
            txtTitle.setText(movie.getTitle());
            txtGenre.setText(movie.getGenre());
            txtDuration.setText(movie.getDuration() + " min");
            txtOverview.setText(movie.getOverview());

            Glide.with(context)
                    .load(movie.getImagePath())
                    .into(mvMovie);
        }
    }
}

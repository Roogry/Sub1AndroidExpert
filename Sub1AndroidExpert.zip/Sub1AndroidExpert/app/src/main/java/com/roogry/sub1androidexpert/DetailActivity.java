package com.roogry.sub1androidexpert;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.roogry.sub1androidexpert.model.MovieItem;

public class DetailActivity extends AppCompatActivity {

    public static String EXTRA_MOVIE = "EXTRA_MOVIE";
    ImageView mvBackdrop, mvMovie;
    TextView txtTitle, txtGenre, txtDuration, txtOverview;
    MovieItem movieItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        initLayout();

        movieItem = getIntent().getParcelableExtra(EXTRA_MOVIE);

        setData();
    }

    private void setData() {
        txtTitle.setText(movieItem.getTitle());
        txtGenre.setText(movieItem.getGenre());
        txtDuration.setText(movieItem.getDuration() + " min");
        txtOverview.setText(movieItem.getOverview());

        Glide.with(this)
                .load(movieItem.getImagePath())
                .into(mvMovie);

        Glide.with(this)
                .load(movieItem.getBackDropPath())
                .into(mvBackdrop);
    }

    private void initLayout() {
        getSupportActionBar().setTitle("Detail Movie");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        mvBackdrop = findViewById(R.id.mvBackdrop);
        mvMovie = findViewById(R.id.mvMovie);
        txtTitle = findViewById(R.id.txtTitle);
        txtGenre = findViewById(R.id.txtGenre);
        txtDuration = findViewById(R.id.txtDuration);
        txtOverview = findViewById(R.id.txtOverview);
    }

    @Override
    public boolean onSupportNavigateUp() {
        this.finish();
        return true;
    }
}

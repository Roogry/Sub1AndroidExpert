package com.roogry.sub1androidexpert;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.roogry.sub1androidexpert.Adapter.MovieAdapter;
import com.roogry.sub1androidexpert.model.MovieItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private MovieAdapter adapter;
    private ArrayList<MovieItem> movieItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar().setTitle("Trending Movies");
        addItems();

        adapter = new MovieAdapter(this, movieItems);
        ListView lv = findViewById(R.id.lv);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_MOVIE, movieItems.get(position));
                startActivity(intent);
            }
        });
    }

    public void addItems() {
        movieItems = new ArrayList<>();

        MovieItem movieItem1 = new MovieItem();
        movieItem1.setId(1);
        movieItem1.setTitle("Spider-Man: Far from Home");
        movieItem1.setGenre("Action, Adventure, Sci-Fi");
        movieItem1.setDuration(129);
        movieItem1.setOverview("Peter Parker and his friends go on a summer trip to Europe. However, they will hardly be able to rest - Peter will have to agree to help Nick Fury uncover the mystery of creatures that cause natural disasters and destruction throughout the continent.");
        movieItem1.setImagePath("https://image.tmdb.org/t/p/original/dzg8lHS78l5Xxpd2EM5H541Qn2s.jpg");
        movieItem1.setBackDropPath("https://image.tmdb.org/t/p/original/nsv7x6bBPF2nedmlHFk1mxhPTWm.jpg");
        movieItems.add(movieItem1);

        MovieItem movieItem2 = new MovieItem();
        movieItem2.setId(2);
        movieItem2.setTitle("Venom (2018)");
        movieItem2.setGenre("Action, Sci-Fi");
        movieItem2.setDuration(102);
        movieItem2.setOverview("Investigative journalist Eddie Brock attempts a comeback following a scandal, but accidentally becomes the host of Venom, a violent, super powerful alien symbiote. Soon, he must rely on his newfound powers to protect the world from a shadowy organization looking for a symbiote of their own.");
        movieItem2.setImagePath("https://image.tmdb.org/t/p/original/2uNW4WbgBXL25BAbXGLnLqX71Sw.jpg");
        movieItem2.setBackDropPath("https://image.tmdb.org/t/p/original/VuukZLgaCrho2Ar8Scl9HtV3yD.jpg");
        movieItems.add(movieItem2);

        MovieItem movieItem3 = new MovieItem();
        movieItem3.setId(3);
        movieItem3.setTitle("Deadpool 2");
        movieItem3.setGenre("Action, Comedy, Adventure");
        movieItem3.setDuration(121);
        movieItem3.setOverview("Wisecracking mercenary Deadpool battles the evil and powerful Cable and other bad guys to save a boy's life.");
        movieItem3.setImagePath("https://image.tmdb.org/t/p/original/to0spRl1CMDvyUbOnbb4fTk3VAd.jpg");
        movieItem3.setBackDropPath("https://image.tmdb.org/t/p/original/16nOLYcUUieCfpcxPwAKzSCcnZn.jpg");
        movieItems.add(movieItem3);

        MovieItem movieItem4 = new MovieItem();
        movieItem4.setId(4);
        movieItem4.setTitle("Ralph Breaks the Internet");
        movieItem4.setGenre("Animation, Adventure, Comedy");
        movieItem4.setDuration(102);
        movieItem4.setOverview("Video game bad guy Ralph and fellow misfit Vanellope von Schweetz must risk it all by traveling to the World Wide Web in search of a replacement part to save Vanellope's video game, \"Sugar Rush.\" In way over their heads, Ralph and Vanellope rely on the citizens of the internet -- the netizens -- to help navigate their way, including an entrepreneur named Yesss, who is the head algorithm and the heart and soul of trend-making site BuzzzTube.");
        movieItem4.setImagePath("https://image.tmdb.org/t/p/original/qEnH5meR381iMpmCumAIMswcQw2.jpg");
        movieItem4.setBackDropPath("https://image.tmdb.org/t/p/original/qDQEQbgP3v7B9IYLAUcYexNrVYP.jpg");
        movieItems.add(movieItem4);

        MovieItem movieItem5 = new MovieItem();
        movieItem5.setId(5);
        movieItem5.setTitle("Captain Marvel");
        movieItem5.setGenre("Action, Adventure, Sci-Fi");
        movieItem5.setDuration(124);
        movieItem5.setOverview("The story follows Carol Danvers as she becomes one of the universe’s most powerful heroes when Earth is caught in the middle of a galactic war between two alien races. Set in the 1990s, Captain Marvel is an all-new adventure from a previously unseen period in the history of the Marvel Cinematic Universe.");
        movieItem5.setImagePath("https://image.tmdb.org/t/p/original/AtsgWhDnHTq68L0lLsUrCnM7TjG.jpg");
        movieItem5.setBackDropPath("https://image.tmdb.org/t/p/original/w2PMyoyLU22YvrGK3smVM9fW1jj.jpg");
        movieItems.add(movieItem5);
    }
}
